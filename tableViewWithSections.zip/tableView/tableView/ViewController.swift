//
//  ViewController.swift
//  tableView
//
//  Created by Ireshika on 3/14/16.
//  Copyright © 2016 Ireshika. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    let devCourse=[("java","Basic"),("Ios","intermediate"),(".net","Hard"),("xamarin","Basic")]
    
    let Course=[("1","Basic"),("2","intermediate"),(".3","Hard"),("4","Basic")]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section==0){
            return devCourse.count}
        else{
            return Course.count}
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell=tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as UITableViewCell
        if(indexPath.section==0){
            let(course,Level)=devCourse[indexPath.row]
            cell.textLabel?.text=course
            cell.detailTextLabel?.text=Level

        }
        else{
            let(course,Level)=Course[indexPath.row]
            cell.textLabel?.text=course
            cell.detailTextLabel?.text=Level

        }
        cell.imageView?.image=UIImage(named: "Image")
        return cell
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section==0){
            
        return "Developer Section"}
            else{
            return "Level Section"
            }
    }
    
}

